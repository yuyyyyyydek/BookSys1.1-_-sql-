package com.book.one;

public class Main {
    public static void main(String[] args) {
        new Login().initFrame();//主要程序@禁止注释以及删除//程序主程序 end start

    }

}
